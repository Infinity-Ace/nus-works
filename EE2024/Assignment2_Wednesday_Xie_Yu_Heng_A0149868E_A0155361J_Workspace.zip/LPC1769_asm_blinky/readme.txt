LPC1769_asm_blinky

CK Tham, ECE, NUS
June 2011

Configures PINSEL1 and GPIO to make LED2 on LPCXpresso board blink.