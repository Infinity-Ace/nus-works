/*****************************************************************************
 *   A demo example using several of the peripherals on the base board
 *
 *   Copyright(C) 2011, EE2024
 *   All rights reserved.
 *
 ******************************************************************************/
/* LPC Libraries */
#include "LPC17xx.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_i2c.h"
#include "lpc17xx_ssp.h"
#include "lpc17xx_uart.h"

/* EaBaseboard Libraries */
#include "pca9532.h"
#include "acc.h"
#include "oled.h"
#include "rgb.h"
#include "light.h"
#include "temp.h"
#include "led7seg.h"

/* C Libraries */
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "string.h"

/* Definitions */
#define g 64.0

/* Tick variables */
uint32_t msTicks;
uint32_t oneSecond = 0;
uint32_t tenSecond = 0;
uint32_t rgbDelay = 0;

/* Switch Variables */
volatile uint8_t sw3Presses = 0;
volatile uint8_t sw4State = 1;

/* Acceleration Variables */
int32_t ACC_THRESHOLD = 0.4*g;
uint8_t ACC_WARNING = 0;
int32_t xoff = 0;
int32_t yoff = 0;
int32_t zoff = 0;
int8_t x = 0;
int8_t y = 0;
int8_t z = 0;

/* Temperature Variables */
int32_t TEMP_HIGH_THRESHOLD = 28;
uint8_t TEMP_WARNING = 0;
volatile double tempValue = 0;

/* Light Variables */
int32_t OBSTACLE_NEAR_THRESHOLD = 3000;
uint8_t OBST_WARNING = 0;
volatile int lightValue = 0;

/* 7 Segment Display Variables */
uint8_t countDownSeconds = 0;

/* 7 Segment Display Characters */
const char countDownDisplay[] = "FEDCBA9876543210";

/* 7 Segment Display Flag */
uint8_t countDownBegin = 0;

/* OLED Strings */
const char oledDisplayStationary[] = "STATIONARY";
const char oledDisplayLaunch[] = "LAUNCH    ";
const char oledDisplayReturn[] = "RETURN    ";
const char oledBlank[] = "               ";
const char oledTempWarning[]= "Temp. too high ";
const char oledAccWarning[] = "Veer off course";
const char oledObstWarning[] = "Obstacle near  ";
char oledDisplayTemp[] = " ";
char oledDisplayX[] = " ";
char oledDisplayY[] = " ";

/* UART Strings */
const char uartDisplayStationary[] = "Entering STATIONARY Mode \r\n";
const char uartDisplayLaunch[] = "Entering LAUNCH Mode \r\n";
const char uartDisplayReturn[] = "Entering RETURN Mode \r\n";
const char uartTempWarning[] = "Temp. too high.\r\n";
const char uartAccWarning[] = "Veer off course.\r\n";
const char uartObstWarning[] = "Obstacle Near.\r\n";
const char uartObstClear[] = "Obstacle Avoided.\r\n";
char uartDisplayValues[50] = " ";

/* UART Flags */
uint8_t uartTempWarningFlag = 0;
uint8_t uartAccWarningFlag = 0;
uint8_t uartObstWarningFlag = 0;
uint8_t uartObstClearFlag = 10;
uint8_t flagR = 0;
uint8_t flagP = 0;
uint8_t flagT = 0;

/* Other Flags */
uint8_t modeChangeFlag = 0;

/* Enumeration for the different modes */
enum Mode{STATIONARY, LAUNCH, RETURN};

/* Current Mode */
uint8_t mode = STATIONARY;

/* Temperature Interrupt Variables */
volatile int tempEdges = 0;
volatile int t1 = 0;
volatile int t2 = 0;
uint32_t NUM_HALF_PERIODS = 340;
uint32_t TEMP_SCALAR_DIV10 = 1;
uint32_t newPeriod = 0;

/* Function Prototypes */
void SysTick_Handler(void); // Systick Handler
uint32_t getTicks(void); // Returns current ticks in ms
unsigned int getPrescalar(uint8_t timerPeripheralClockBit); // Prescalar for Timers
void init_timer0(); // Timer0 (333ms)
void init_timer1(); // Timer1 (1000ms)
void TIMER0_IRQHandler(void); // Timer0 Handler
void TIMER1_IRQHandler(void); // Timer1 Handler
void EINT3_IRQHandler(void);	// ENT3 Handler
void UART3_IRQHandler(void); // UART3 handler
static void init_ssp(void); // Initializes and configures SSP
static void init_i2c(void);	// Initializes and configures I2C
static void init_GPIO(void); // Initializes and configures GPIO
void pinsel_uart3(void); // UART PINSEL Configuration
void init_uart(void);	// Initializes and sets up UART
void choose_mode(void);	// Determines the operations during different modes
void temp_warning(void);	// Checks TEMP_WARNING condition
void acc_reader(void);	// Returns accelerometer reading and checks ACC_WARNING condition
void light_reader(void);	// Returns light sensor reading and checks OBST_WARNING condition
void countdown_run(void); // Initiates countdown and displays characters on the 7 segment display
void display_oled(void);	// Operates the OLED display
void rgb_flash (void);	// Flashes RGB during TEMP_WARNING and ACC_WARNING
void led_array(void);	// Operates PCA9532 LED array
void uart_display_mode(void);	// Displays current mode UART message on TeraTerm terminal
void uart_display(void);	// Displays the respective UART messages
void uart_callback (void); // UART callback function for receiving TeraTerm terminal inputs

/**
 * SysTick Handler
 * Increments msTicks every 1ms
 */
void SysTick_Handler(void) {
	msTicks++;
}

/* Returns current ticks */
uint32_t getTicks() {
	return msTicks;
}

/**
 * Obtains the Prescalar value from the given timer Peripheral Clock Bit
 * Referenced from: https://exploreembedded.com/wiki/LPC1768:_Timers
 */
unsigned int getPrescalar(uint8_t timerPeripheralClockBit){
    unsigned int peripheralClock, prescalar;

    // Get the peripheral clock info for required timer
    if(timerPeripheralClockBit < 10)
    	peripheralClock = (LPC_SC->PCLKSEL0 >> timerPeripheralClockBit) & 0x03;
    else
    	peripheralClock = (LPC_SC->PCLKSEL1 >> timerPeripheralClockBit) & 0x03;

    // Decode the bits to determine the peripheral clock, obtained from the LPC Timer
    switch ( peripheralClock ){
		case 0x00:
			peripheralClock = SystemCoreClock/4;
			break;

		case 0x01:
			peripheralClock = SystemCoreClock;
			break;

		case 0x02:
			peripheralClock = SystemCoreClock/2;
			break;

		case 0x03:
			peripheralClock = SystemCoreClock/8;
			break;
    }

    // Prescalar for 1us (1000000Counts/sec)
    prescalar = peripheralClock/1000000 - 1;

    return prescalar;
}

/**
 * Initializes timer0 interrupt
 * Timer0 will run every 333 milliseconds
 * Referenced from: https://exploreembedded.com/wiki/LPC1768:_Timers
 */
void init_timer0(){
	LPC_SC->PCONP |= (1 << 1);			// Power Up Timer 0
	LPC_SC->PCLKSEL0 |= 0x01 << 2;		// Select the Timer 0 pin
    LPC_TIM0->MCR  = (1<<0) | (1<<1);	// Clear Timer Counter on Match Register 0 match and Generate Interrupt
    LPC_TIM0->PR   = getPrescalar(2);	// Prescalar for 1us
    LPC_TIM0->MR0  = 333333;   			// Load timer value to generate 1ms delay
    LPC_TIM0->TCR  = (1 << 0);			// Start timer by setting the Counter Enable
	NVIC_EnableIRQ(TIMER0_IRQn);
}

/**
 * Initializes timer0 interrupt
 * Timer1 will run every 1 second
 * Referenced from: https://exploreembedded.com/wiki/LPC1768:_Timers
 */
void init_timer1(){
	LPC_SC->PCONP |= (1 << 2);			// Power Up Timer 1
	LPC_SC->PCLKSEL0 |= 0x01 << 4;		// Select the Timer 1 pin
    LPC_TIM1->MCR  = (1<<0) | (1<<1);	// Clear Timer Counter on Match Register 0 match and Generate Interrupt
    LPC_TIM1->PR   = getPrescalar(4);	// Prescalar for 1us
    LPC_TIM1->MR0  = 1000000;   		// Load timer value to generate 1s delay
    LPC_TIM1->TCR  = (1 << 0);			// Start timer by setting the Counter Enable
	NVIC_EnableIRQ(TIMER1_IRQn);
}

/**
 * Handles Timer0 interrupt
 * Referenced from: https://exploreembedded.com/wiki/LPC1768:_Timers
 */
void TIMER0_IRQHandler(void){
    unsigned int isrMask;
    isrMask = LPC_TIM0->IR;
    LPC_TIM0->IR = isrMask;		// Clear the Interrupt Bit
    rgb_flash();
	rgbDelay = !rgbDelay;
}

/**
 * Handles Timer1 interrupt
 * Referenced from: https://exploreembedded.com/wiki/LPC1768:_Timers
 */
void TIMER1_IRQHandler(void){
    unsigned int isrMask;
    isrMask = LPC_TIM1->IR;
    LPC_TIM1->IR = isrMask;		// Clear the Interrupt Bit
    if (mode == STATIONARY && countDownBegin == 1){
    	countDownSeconds++;
    }
}

/* Handles EINT3 GPIO interrupts */
void EINT3_IRQHandler(void){
	/* SW3 Interrupt Handler*/
	if ((LPC_GPIOINT->IO0IntStatF >> 4) & 0x1) {
		sw3Presses++;
		LPC_GPIOINT ->IO0IntClr = 1<<4;
	}

 	/* Temperature Interrupt Handler */
	if (((LPC_GPIOINT->IO0IntStatF >> 2) & 0x1) || ((LPC_GPIOINT->IO0IntStatR >> 2) & 0x1)) {
		tempEdges++;
		LPC_GPIOINT ->IO0IntClr = 1<<2;

	    if (newPeriod == 0) {
			t1 = getTicks();
			newPeriod = 1;
		}

		if (tempEdges >= (NUM_HALF_PERIODS)) {
			t2 = getTicks();

			if (t2 > t1) {
				t2 = t2 - t1;
			} else {
				t2 = (0xFFFFFFFF - t1 + 1) + t2;
			}

			tempEdges = 0;
			newPeriod = 0;
			tempValue = ((2*1000*t2) / (NUM_HALF_PERIODS*TEMP_SCALAR_DIV10) - 2731) / 10.0 ;
		}
	}
}

/* Handles UART3 interrupts */
void UART3_IRQHandler(void) {
	UART3_StdIntHandler();
}

/* Initializes and configures SSP */
static void init_ssp(void){
	SSP_CFG_Type SSP_ConfigStruct;
	PINSEL_CFG_Type PinCfg;

	/*
	 * Initialize SPI pin connect
	 * P0.7 - SCK;
	 * P0.8 - MISO
	 * P0.9 - MOSI
	 * P2.2 - SSEL - used as GPIO
	 */
	PinCfg.Funcnum = 2;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Portnum = 0;
	PinCfg.Pinnum = 7;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 8;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 9;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Funcnum = 0;
	PinCfg.Portnum = 2;
	PinCfg.Pinnum = 2;
	PINSEL_ConfigPin(&PinCfg);

	SSP_ConfigStructInit(&SSP_ConfigStruct);

	// Initialize SSP peripheral with parameter given in structure above
	SSP_Init(LPC_SSP1, &SSP_ConfigStruct);

	// Enable SSP peripheral
	SSP_Cmd(LPC_SSP1, ENABLE);
}

/* Initializes and configures I2C */
static void init_i2c(void){
	PINSEL_CFG_Type PinCfg;

	/* Initialize I2C2 pin connect */
	// Initialise pins for Light Sensor
	PinCfg.Funcnum = 2;
	PinCfg.Pinnum = 10;
	PinCfg.Portnum = 0;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 11;
	PINSEL_ConfigPin(&PinCfg);

	// Initialize I2C peripheral
	I2C_Init(LPC_I2C2, 100000);

	/* Enable I2C1 operation */
	I2C_Cmd(LPC_I2C2, ENABLE);
}

/* Initializes and configures GPIO */
static void init_GPIO(void){
	PINSEL_CFG_Type PinCfg;

	// Initialize SW3 button
	PinCfg.Funcnum = 0;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Portnum = 0;
	PinCfg.Pinnum = 4;
	PINSEL_ConfigPin(&PinCfg);
	GPIO_SetDir(0, 1<<4, 0);

	// Initialize SW4 button
	PinCfg.Funcnum = 0;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Portnum = 1;
	PinCfg.Pinnum = 31;
	PINSEL_ConfigPin(&PinCfg);
	GPIO_SetDir(1, 1<<31, 0);

	// Initialize Temperature Interrupt
	PinCfg.Funcnum = 0;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Portnum = 0;
	PinCfg.Pinnum = 2;
	PINSEL_ConfigPin(&PinCfg);
	GPIO_SetDir(0, 1<<2, 0);

	//Initialize Blue LED
	PinCfg.Funcnum = 0;
	PinCfg.Portnum = 0;
	PinCfg.Pinnum = 26;
	PINSEL_ConfigPin(&PinCfg);
	GPIO_SetDir(0, 1<<26, 1);

	//Initialize Red LED
	PinCfg.Funcnum = 0;
	PinCfg.Portnum = 2;
	PinCfg.Pinnum = 0;
	PINSEL_ConfigPin(&PinCfg);
	GPIO_SetDir(2, 1<<0, 1);
}

/* Initializes UART3 */
void pinsel_uart3(void) {
	PINSEL_CFG_Type PinCfg;
	PinCfg.Funcnum = 2;
	PinCfg.Pinnum = 0;
	PinCfg.Portnum = 0;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 1;
	PINSEL_ConfigPin(&PinCfg);
}

/* Configure UART3 */
void init_uart(void){
	UART_CFG_Type uartCfg;
	uartCfg.Baud_rate = 115200;
	uartCfg.Databits = UART_DATABIT_8;
	uartCfg.Parity = UART_PARITY_NONE;
	uartCfg.Stopbits = UART_STOPBIT_1;
	//pin select for uart3;
	pinsel_uart3();
	// supply power & setup working par.s for UART3
	UART_Init(LPC_UART3, &uartCfg);
	// enable transmit for uart3
	UART_TxCmd(LPC_UART3, ENABLE);

	UART_FIFO_CFG_Type UARTFIFOConfigStruct;
	UART_FIFOConfigStructInit(&UARTFIFOConfigStruct);
	UART_FIFOConfig(LPC_UART3, &UARTFIFOConfigStruct);

	UART_SetupCbs(LPC_UART3, 0, (void *) &uart_callback);

	UART_IntConfig(LPC_UART3, UART_INTCFG_RBR, ENABLE);
}

/* Main Function */
int main (void) {
	/* Configure SysTick */
	if (SysTick_Config(SystemCoreClock / 1000)) {
		while (1);
	}

	/* Initialize all peripherals */
	init_timer0();
	init_timer1();
	init_i2c();
    init_ssp();
    init_GPIO();
    init_uart();
    oled_init();
    pca9532_init();
    acc_init();
    led7seg_init();
    light_enable();
    temp_init(&getTicks);

	/* Light Sensor Setting */
	light_setRange(LIGHT_RANGE_4000);

	/* SW3 Interrupt */
	LPC_GPIOINT->IO0IntEnF |= 1 << 4;

	/* Temp Interrupt */
	LPC_GPIOINT->IO0IntEnF |= 1 << 2;
	LPC_GPIOINT->IO0IntEnR |= 1 << 2;

	/* NVIC Configurations */
	NVIC_ClearPendingIRQ(EINT3_IRQn);
	NVIC_EnableIRQ(UART3_IRQn);
	NVIC_EnableIRQ (EINT3_IRQn);

	NVIC_SetPriorityGrouping(5);
	NVIC_SetPriority(TIMER0_IRQn, 0x00);
	NVIC_SetPriority(TIMER1_IRQn, 0x01);
	NVIC_SetPriority(EINT3_IRQn, 0x18);

	/* Clear OLED at the start */
    oled_clearScreen(OLED_COLOR_BLACK);

	/* Calibrate Accelerometer
	 * Assume base board in zero-g position when reading first value
	 */

	acc_read(&x, &y, &z);
	xoff = 0-x;
	yoff = 0-y;
	zoff = 0-z;

	/* Main polling loop */
    while (1)
    {
    	choose_mode();
    }
}

/* Determines the operations during different modes */
void choose_mode(void){
	int withinOneSecond = 0;

	if (mode == STATIONARY){

		/* Sets 'F' on 7 segment display and clear LED array once upon entering Stationary Mode
		 * Displays "Stationary Mode" in TeraTerm once upon entering Stationary Mode
		 */
		if (modeChangeFlag == 0) {
			led7seg_setChar('F',FALSE);
			pca9532_setLeds (0x0000, 0xFFFF);
			uart_display_mode();
			modeChangeFlag = 1;
		}

		sw4State = (GPIO_ReadValue(1) >> 31) & 0x01;
		temp_warning();
		display_oled();

		/* Begin Countdown */
		if (sw3Presses >= 1) {
			sw3Presses = 0;
			countDownBegin = 1;
			countdown_run();
		}

	} else if (mode == LAUNCH) {

		/*  Displays "Launch Mode" in TeraTerm once upon entering Launch Mode */
		if (modeChangeFlag == 0) {
			uart_display_mode();
			modeChangeFlag = 1;
		}

		sw4State = (GPIO_ReadValue(1) >> 31) & 0x01;
		temp_warning();
		sw4State = (GPIO_ReadValue(1) >> 31) & 0x01;
		acc_reader();
		display_oled();
		uart_display();

		if (sw3Presses >= 1) {

			/* Sets oneSecond to current msTicks to keep track of the 1 second interval */
			if (withinOneSecond == 0){
				oneSecond = msTicks;
				withinOneSecond = 1;
			}

			/* Checks if sw3 is pressed again within the 1 second interval */
			while (((msTicks - oneSecond) <= 1000) && (withinOneSecond == 1)){

				temp_warning();
				acc_reader();
				display_oled();
				uart_display();

				/* Launch to Return */
				if (sw3Presses == 2) {
					sw3Presses = 0;
					withinOneSecond = 0;
					TEMP_WARNING = 0;
					ACC_WARNING = 0;
					modeChangeFlag = 0;
					mode = RETURN;
				}
			}

			sw3Presses = 0;
			withinOneSecond = 0;
		}

	} else if (mode == RETURN) {

		/*  Displays "Return Mode" in TeraTerm once upon entering Return Mode */
		if (modeChangeFlag == 0) {
			uart_display_mode();
			modeChangeFlag = 1;
		}

		light_reader();
		led_array();
		display_oled();
		uart_display();

		/* Return to Stationary */
		if (sw3Presses >= 1){
			sw3Presses = 0;
			OBST_WARNING = 0;
			modeChangeFlag = 0;
			mode = STATIONARY;
		}
	}
}

/* Checks TEMP_WARNING condition */
void temp_warning(void){
	if (tempValue > TEMP_HIGH_THRESHOLD){
		TEMP_WARNING = 1;
	}

	if (sw4State == 0) {
		TEMP_WARNING = 0;
		uartTempWarningFlag = 0;
	}
}

/* Returns accelerometer reading and checks ACC_WARNING condition */
void acc_reader(void) {
	acc_read(&x, &y, &z);
	x = x+xoff;
	y = y+yoff;
	z = z+zoff;

	if ((abs(x) > ACC_THRESHOLD) || (abs(y) > ACC_THRESHOLD)) {
		ACC_WARNING = 1;
	}

	if (sw4State == 0) {
		ACC_WARNING = 0;
		uartAccWarningFlag = 0;
	}
}

/* Returns light sensor reading and checks OBST_WARNING condition */
void light_reader(void){
	lightValue = light_read();

	if (lightValue > OBSTACLE_NEAR_THRESHOLD){
		OBST_WARNING = 1;
		uartObstClearFlag = 0;
	}	else {
		OBST_WARNING = 0;
		uartObstWarningFlag = 0;
	}
}

/* Initiates countdown and displays characters on the 7 segment display */
void countdown_run(void) {
	while ((countDownSeconds <= 15)){
		led7seg_setChar(countDownDisplay[countDownSeconds],FALSE);
		temp_warning();
		display_oled();

		/* Breaks out of countdown if TEMP_WARNING appears */
		if (TEMP_WARNING == 1){
			countDownSeconds = 0;
			countDownBegin = 0;
			led7seg_setChar('F',FALSE);
			break;
		}
	}

	/* Switch to LAUNCH Mode if countdown is successful */
	if (countDownSeconds >= 15) {
		TEMP_WARNING = 0;
		countDownSeconds = 0;
		countDownBegin = 0;
		modeChangeFlag = 0;
		mode = LAUNCH;
    }
}

/* Operates the OLED display */
void display_oled(void){
	if (mode == STATIONARY) {

		if (TEMP_WARNING == 1) {
			oled_putString(0,0, (uint8_t*)oledDisplayStationary, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayTemp, "Temp: %2.2f    ", tempValue);
			oled_putString(0,10, (uint8_t*)oledDisplayTemp, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,20, (uint8_t*)oledTempWarning, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,30, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,40, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,50, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);

		} else {
			oled_putString(0,0, (uint8_t*)oledDisplayStationary, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayTemp, "Temp: %2.2f    ", tempValue);
			oled_putString(0,10, (uint8_t*)oledDisplayTemp, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,20, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,30, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,40, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,50, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		}

	} else if (mode == LAUNCH) {

		if ((TEMP_WARNING == 1) && (ACC_WARNING == 1)) {
			oled_putString(0,0, (uint8_t*)oledDisplayLaunch, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayTemp,"Temp: %2.2f    ", tempValue);
			oled_putString(0,10, (uint8_t*)oledDisplayTemp, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayX, "X: %2.2fg       ", x/g);
			oled_putString(0,20, (uint8_t*)oledDisplayX, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayY, "Y: %2.2fg       ", y/g);
			oled_putString(0,30, (uint8_t*)oledDisplayY, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,40, (uint8_t*)oledTempWarning, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,50, (uint8_t*)oledAccWarning, OLED_COLOR_WHITE, OLED_COLOR_BLACK);

		} else if (TEMP_WARNING == 1) {
			oled_putString(0,0, (uint8_t*)oledDisplayLaunch, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayTemp, "Temp: %2.2f    ", tempValue);
			oled_putString(0,10, (uint8_t*)oledDisplayTemp, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayX, "X: %2.2fg        ", x/g);
			oled_putString(0,20, (uint8_t*)oledDisplayX, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayY, "Y: %2.2fg        ", y/g);
			oled_putString(0,30, (uint8_t*)oledDisplayY, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,40, (uint8_t*)oledTempWarning, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,50, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);

		} else if (ACC_WARNING == 1) {
			oled_putString(0,0, (uint8_t*)oledDisplayLaunch, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayTemp, "Temp: %2.2f    ", tempValue);
			oled_putString(0,10, (uint8_t*)oledDisplayTemp, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayX, "X: %2.2fg        ", x/g);
			oled_putString(0,20, (uint8_t*)oledDisplayX, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayY, "Y: %2.2fg        ", y/g);
			oled_putString(0,30, (uint8_t*)oledDisplayY, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,40, (uint8_t*)oledAccWarning, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,50, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);

		} else {
			oled_putString(0,0, (uint8_t*)oledDisplayLaunch, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayTemp, "Temp: %2.2f    ", tempValue);
			oled_putString(0,10, (uint8_t*)oledDisplayTemp, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayX, "X: %2.2fg        ", x/g);
			oled_putString(0,20, (uint8_t*)oledDisplayX, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			sprintf(oledDisplayY, "Y: %2.2fg        ", y/g);
			oled_putString(0,30, (uint8_t*)oledDisplayY, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,40, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,50, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		}

	} else if (mode == RETURN) {

		if (OBST_WARNING == 1) {
			oled_putString(0,0, (uint8_t*)oledDisplayReturn, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,10, (uint8_t*)oledObstWarning, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,20, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,30, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,40, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,50, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		} else {
			oled_putString(0,0, (uint8_t*)oledDisplayReturn, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,10, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,20, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,30, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,40, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
			oled_putString(0,50, (uint8_t*)oledBlank, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		}
	}
}

/* Flashes RGB during TEMP_WARNING and ACC_WARNING */
void rgb_flash (void) {

	/* Red and blue LEDs blink alternatively during TEMP_WARNING & ACC_WARNING */
	if (TEMP_WARNING == 1 && ACC_WARNING == 1) {
		if (rgbDelay) {
			GPIO_SetValue(2, (1<<0));
			GPIO_ClearValue(0, (1<<26));
		} else {
			GPIO_SetValue(0, (1<<26));
			GPIO_ClearValue(2, (1<<0));
		}
	}

	/* Red LED blinks during TEMP_WARNING */
	else if (TEMP_WARNING == 1){
		if (rgbDelay) {
			GPIO_SetValue(2, (1<<0));
			GPIO_ClearValue(0, (1<<26));
		} else {
			GPIO_ClearValue(2, (1<<0));
			GPIO_ClearValue(0, (1<<26));
		}
	}

	/* Blue LED blinks during ACC_WARNING */
	else if (ACC_WARNING == 1){
		if (rgbDelay) {
			GPIO_SetValue(0, (1<<26));
			GPIO_ClearValue(2, (1<<0));
		} else {
			GPIO_ClearValue(2, (1<<0));
			GPIO_ClearValue(0, (1<<26));
		}
	} else {
		GPIO_ClearValue(2, (1<<0));
		GPIO_ClearValue(0, (1<<26));
	}
}

/* Operates PCA9532 LED array using bit masking */
void led_array(void){
	if (lightValue < 190){
		pca9532_setLeds (0b0000000000000000, 0xFFFF);
	}

	else if (lightValue >= 190 && lightValue < 380) {
    	pca9532_setLeds (0b1000000000000000, 0xFFFF);
    }

	else if (lightValue >= 380 && lightValue < 570) {
    	pca9532_setLeds (0b1100000000000000, 0xFFFF);
    }

	else if (lightValue >= 570 && lightValue < 750) {
    	pca9532_setLeds (0b1110000000000000, 0xFFFF);
    }

	else if (lightValue >= 750 && lightValue < 940) {
    	pca9532_setLeds (0b1111000000000000, 0xFFFF);
    }

	else if (lightValue >= 940 && lightValue < 1130) {
    	pca9532_setLeds (0b1111100000000000, 0xFFFF);
    }

	else if (lightValue >= 1130 && lightValue < 1310) {
    	pca9532_setLeds (0b1111110000000000, 0xFFFF);
    }

	else if (lightValue >= 1310 && lightValue < 1500) {
    	pca9532_setLeds (0b1111111000000000, 0xFFFF);
    }

	else if (lightValue >= 1500 && lightValue < 1690) {
		pca9532_setLeds (0b1111111100000000, 0xFFFF);
	}

	else if (lightValue >= 1690 && lightValue < 1880) {
		pca9532_setLeds (0b1111111100000001, 0xFFFF);
	}

	else if (lightValue >= 1880 && lightValue < 2070) {
		pca9532_setLeds (0b1111111100000011, 0xFFFF);
	}

	else if (lightValue >= 2070 && lightValue < 2250) {
		pca9532_setLeds (0b1111111100000111, 0xFFFF);
	}

	else if (lightValue >= 2250 && lightValue < 2440) {
		pca9532_setLeds (0b1111111100001111, 0xFFFF);
	}

	else if (lightValue >= 2440 && lightValue < 2630) {
		pca9532_setLeds (0b1111111100011111, 0xFFFF);
	}

	else if (lightValue >= 2630 && lightValue < 2820) {
		pca9532_setLeds (0b1111111100111111, 0xFFFF);
	}

	else if (lightValue >= 2820 && lightValue < 3000) {
		pca9532_setLeds (0b1111111101111111, 0xFFFF);
	}

	else if (lightValue >= 3000) {
		pca9532_setLeds (0b1111111111111111, 0xFFFF);
	}
}

/* Displays current mode UART message on TeraTerm terminal */
void uart_display_mode(void){
	if (mode == STATIONARY) {
		UART_Send(LPC_UART3, (uint8_t *)uartDisplayStationary , strlen(uartDisplayStationary), BLOCKING);

	} else if (mode == LAUNCH) {
		UART_Send(LPC_UART3, (uint8_t *)uartDisplayLaunch , strlen(uartDisplayLaunch), BLOCKING);

	} else if (mode == RETURN) {
		UART_Send(LPC_UART3, (uint8_t *)uartDisplayReturn , strlen(uartDisplayReturn), BLOCKING);
	}
}

/* Displays the respective UART messages */
void uart_display(void) {
	if (mode == LAUNCH){
		/* Displays Temp and Acc values on TeraTerm Terminal every 10 seconds in LAUNCH Mode */
		if ((msTicks - tenSecond) > 10000) {
			tenSecond = msTicks;
			sprintf(uartDisplayValues, "Temp : %2.2f, ACC X : %2.2fg, Y : %2.2fg \r\n", tempValue, x/g, y/g);
			UART_Send(LPC_UART3, (uint8_t *)uartDisplayValues , strlen(uartDisplayValues), BLOCKING);
		}

		if (TEMP_WARNING == 1 && uartTempWarningFlag == 0){
			UART_Send(LPC_UART3, (uint8_t *)uartTempWarning , strlen(uartTempWarning), BLOCKING);
			uartTempWarningFlag = 1;
		}

		if (ACC_WARNING == 1 && uartAccWarningFlag == 0){
			UART_Send(LPC_UART3, (uint8_t *)uartAccWarning , strlen(uartAccWarning), BLOCKING);
			uartAccWarningFlag = 1;
		}

	} else if (mode == RETURN) {
		/* Displays Light values on TeraTerm Terminal every 10 seconds in RETURN Mode */
		if ((msTicks - tenSecond) > 10000) {
			tenSecond = msTicks;
			sprintf(uartDisplayValues, "Obstacle distance : %d \r\n", lightValue);
			UART_Send(LPC_UART3, (uint8_t *)uartDisplayValues , strlen(uartDisplayValues), BLOCKING);
		}

		if (OBST_WARNING == 1 && uartObstWarningFlag == 0){
			UART_Send(LPC_UART3, (uint8_t *)uartObstWarning , strlen(uartObstWarning), BLOCKING);
			uartObstWarningFlag = 1;

		} else if (OBST_WARNING == 0 && uartObstClearFlag == 0) {
			UART_Send(LPC_UART3, (uint8_t *)uartObstClear , strlen(uartObstClear), BLOCKING);
			uartObstClearFlag = 1;
		}
	}
}

/* UART callback function for receiving TeraTerm terminal character inputs
 * If "RPT\r" is received, display values on TeraTerm terminal according to the current mode
 * Mistypes will not work e.g. RPPT\r, RPAT\r, RTPT\r
 * Proceeding characters will not work as well e.g. RPTT\r, RPTTT\r, RPTA\r
 * Preceding characters are acceptable e.g. RRRPT\r, ABCDRPT\r, \rRPT\r
 */
void uart_callback (void) {
	uint8_t data[2];

	UART_Receive(LPC_UART3, data, 1, BLOCKING);
	printf("R");
	data[1] = '\0';

	if (strcmp((char *)data ,"R") == 0) {
		flagR = 1;
	} else if ((strcmp((char *)data ,"P") == 0) && flagR == 1 && flagP == 0) {
		flagP = 1;
	} else if ((strcmp((char *)data ,"T") == 0) && flagP == 1 && flagT == 0) {
		flagT = 1;
	} else if ((strcmp((char *)data ,"\r") == 0) && flagT == 1) {
		if(mode == LAUNCH) {
			sprintf(uartDisplayValues, "Temp : %2.2f, ACC X : %2.2fg, Y : %2.2fg \r\n", tempValue, x/g, y/g);
		}
		else if (mode == RETURN) {
			sprintf(uartDisplayValues, "Obstacle distance : %d \r\n", lightValue);
		}
		UART_Send(LPC_UART3, (uint8_t *)uartDisplayValues , strlen(uartDisplayValues), BLOCKING);
		flagR = flagP = flagT = 0;
	} else {
		flagR = flagP = flagT = 0;
	}
}

void check_failed(uint8_t *file, uint32_t line)
{
	/* User can add his own implementation to report the file name and line number,
	 ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

	/* Infinite loop */
	while(1);
}
